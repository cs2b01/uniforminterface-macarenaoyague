#ifndef BSTREE_H
#define BSTREE_H

#include "node.h"
#include "iterator.h"

template <typename T> 
class BSTree {
    Node<T> *root;
    int nodes;
    bool find(int index, Node<T> **&pointer) {
        while (*pointer != nullptr)
        {
            if ((*pointer)->key < index)
                pointer = &((*pointer)->right);
            else if ((*pointer)->key > index)
                pointer = &((*pointer)->left);
            else if ((*pointer)->key == index)
                return true;
        }
        return false;
    }

    void preOrderPrint(Node<T> *node){
        cout<<node->key<<" "; //se imprime la data o el key?
        if (node->left != nullptr)
            preOrderPrint(node->left);
        if (node->right != nullptr)
            preOrderPrint(node->right);
    }

    void inOrderPrint(Node<T> *node){
        if (node->left != nullptr)
            inOrderPrint(node->left);
        cout<<node->key<<" "; //se imprime la data o el key?
        if (node->right != nullptr)
            inOrderPrint(node->right);
    }

    void postOrderPrint(Node<T> *node){
        if (node->left != nullptr)
            postOrderPrint(node->left);
        if (node->right != nullptr)
            postOrderPrint(node->right);
        cout<<node->key<<" "; //se imprime la data o el key?
    }

public:
    BSTree() : root(nullptr), nodes(0) {};

    bool insert(int key, T data) {
        auto pointer = &root;
        if (find(key, pointer))
        {
            if ((*pointer)->data != data)
                (*pointer)->data = data;
            return false;
        }
        Node<T> *newNode = new Node<T>(key, data);
        *pointer = newNode;
        nodes++;
        return true;
    }

    bool remove(int key) {
        auto pointer = &root;
        if (!find(key, pointer))
            return false;
        if ((*pointer)->right == nullptr and (*pointer)->left == nullptr)
        {
            delete (*pointer);
            (*pointer) = nullptr;
        }
        else if ((*pointer)->right == nullptr xor (*pointer)->left == nullptr)
        {
            Node<T> *temp = (*pointer);
            if ((*pointer)->right == nullptr)
                (*pointer) = (*pointer)->left;
            else
                (*pointer) = (*pointer)->right;
            delete temp;
        }
        else
        {
            Node<T> *temp = (*pointer);
            pointer = &((*pointer)->right);
            while ((*pointer)->left != nullptr)
                pointer = &((*pointer)->left);
            swap((*pointer)->data, temp->data);
            swap((*pointer)->key, temp->key);
            delete (*pointer);
            (*pointer) = nullptr;
        }
        nodes--;
        return true;
    }

    bool hasKey(int key) {
        auto pointer = &root;
        find(key, pointer);
        return  (*pointer) != nullptr;
    } 

    T operator[](int key) {
        // NOTE: For 1+ point, research if it is possible to update the node with this same function (like insert, e.g. tree[2] = "hola")
        auto pointer = &root;
        find(key, pointer);
        if ((*pointer) != nullptr)
            return (*pointer)->data;
        throw std::out_of_range ("There is no information with this key");
    }

    int size() {
        return nodes;
    }

    int height() {
        //incluir la altura en nodos?
        // TODO
    }

    bool empty() const {
        return root == nullptr;
    }

    void traversePreOrder() {
        auto startNode = root;
        preOrderPrint(startNode);
    }

    void traverseInOrder() {
        auto startNode = root;
        inOrderPrint(startNode);
    }

    void traversePostOrder() {
        auto startNode = root;
        postOrderPrint(startNode);
    }

    Iterator<T> begin() { ///cuál es el begin?, arreglar
        /*Node<T> **begin = &root;
        while ((*begin)->left != nullptr)
            begin = (*begin)->left;
        return Iterator<T>(**begin);*/
        return Iterator<T>(root);
    }

    Iterator<T> end() { ///cuál es el end?, arreglar
        /*Node<T> **end = &root;
        while ((*end)->right != nullptr)
            end = (*end)->right;
        return Iterator<T>(**end);*/
        return Iterator<T>(nullptr);
    }

    ~BSTree() {
        if (root != nullptr)
            root->killSelf();
    }
};

#endif
