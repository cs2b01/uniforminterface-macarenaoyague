#ifndef ITERATOR_H
#define ITERATOR_H

#include <utility>
#include <vector>
#include "node.h"

template <typename T> 
class Iterator {
    Node<T>* node;
public:
    explicit Iterator() {
        // TODO
    }

    explicit Iterator(Node<T>* node) {
        // TODO
        this->node = node;
    }

    Iterator<T>& operator=(const Iterator<T> &other) {          
        // TODO
    }

    bool operator!=(Iterator<T> other) {
        // TODO
    }

    Iterator<T>& operator++() {
        //iterator in order
        // TODO
    }

    pair<int, T> operator*() {
        //pair<int, T> pair = make_pair (node->key, node->data); o así?
        //si es nullptr, añadir throw
        return make_pair (node->key, node->data);
    }
};

#endif
