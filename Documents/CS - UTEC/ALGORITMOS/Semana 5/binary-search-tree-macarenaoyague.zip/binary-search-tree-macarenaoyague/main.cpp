#include <iostream>
#include "tester/tester.h"

using namespace std;

void sortAndPrune(vector<int>& array) {
    sort(array.begin(), array.end());
    auto last = unique(array.begin(), array.end());
    array.erase(last, array.end());
}

int main(int argc, char *argv[]) {
    cout << "===========================================================" << endl;
    cout << "Binary Search Tree Practice" << endl;
    cout << "===========================================================" << endl << endl;

    /*
       BSTree<char> tree;
       tree.insert(5, 'a');
       tree.insert(3, 'h');
       tree.insert(2, 'a');
       tree.insert(20, 'a');
       tree.insert(11, 'a');
       tree.insert(1, '9');
       tree.remove(5);
       cout<<tree.size();

       tree.insert(13, 'b');
       tree.insert(30, 'a');
       tree.insert(4, 'a');
       tree.insert(12, 'a');
       tree.insert(14, 'a');
       tree.insert(9, 'a');
       tree.insert(8, 'a');
       tree.insert(30, 'a');
       tree.insert(11, 'x');*/

    /*tree.remove(5);
    tree.remove(3);
    tree.remove(2);
    tree.remove(20);
    tree.remove(11);
    tree.remove(1);

    cout<<tree.size();*/

     /*BSTree<char> tree;
     tree.insert(5, 'a');
     tree.insert(3, 'h');
     tree.insert(2, 'a');
     tree.insert(20, 'a');
     tree.insert(11, 'a');
     tree.insert(1, '9');
     tree.insert(13, 'b');
     tree.insert(30, 'a');
     tree.insert(4, 'a');
     tree.insert(12, 'a');
     tree.insert(14, 'a');
     tree.insert(9, 'a');
     tree.insert(8, 'a');
     tree.insert(30, 'a');
     tree.insert(11, 'x');
     tree.traversePostOrder(); cout<<"   "<<tree.size()<<endl;
     tree.remove(5);
    tree.traversePostOrder(); cout<<"   "<<tree.size()<<endl;
     tree.remove(3);
    tree.traversePostOrder(); cout<<"   "<<tree.size()<<endl;
     tree.remove(11);
     tree.traversePostOrder(); cout<<"   "<<tree.size()<<endl;
     tree.remove(4);
    tree.traversePostOrder(); cout<<"   "<<tree.size()<<endl;
    tree.remove(30);
    tree.traversePostOrder(); cout<<"   "<<tree.size()<<endl;
    tree.remove(13);
    tree.traversePostOrder(); cout<<"   "<<tree.size()<<endl;
tree.remove(8);
    tree.traversePostOrder(); cout<<"   "<<tree.size()<<endl;*/

   Tester::execute();
    return EXIT_SUCCESS;
}